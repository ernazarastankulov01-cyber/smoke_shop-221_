# Dorm Cigarette Ordering & Reviews (Example)
**Warning:** This is an example project for educational purposes only.
Ensure you follow local laws and age restrictions before using or deploying.

## What it is
Simple Flask app where dorm residents can:
- Place an order specifying room number and cigarette type.
- Leave reviews for orders (create & edit).
- View list of orders and reviews.

## Run locally
1. Create virtualenv (optional):
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```
2. Install requirements:
   ```
   pip install -r requirements.txt
   ```
3. Initialize DB and run:
   ```
   flask --app app.py run
   ```
4. Open http://127.0.0.1:5000

## Notes
- This is a minimal demo. No authentication. Do NOT use in production.
- Add age checks, authentication, CSRF protection, and deploy with care.
