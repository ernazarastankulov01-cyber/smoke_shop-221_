from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).with_name('data.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room TEXT NOT NULL,
        item TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    cur.execute('''
    CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        author TEXT,
        text TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
    )
    ''')
    conn.commit()
    conn.close()

app = Flask(__name__)
app.secret_key = 'dev-key'  # replace in production

@app.before_first_request
def setup():
    init_db()

@app.route('/')
def index():
    conn = get_db()
    orders = conn.execute('SELECT * FROM orders ORDER BY created_at DESC').fetchall()
    reviews = conn.execute('SELECT * FROM reviews ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('index.html', orders=orders, reviews=reviews)

@app.route('/order', methods=['GET','POST'])
def order():
    if request.method == 'POST':
        room = request.form.get('room','').strip()
        item = request.form.get('item','').strip()
        if not room or not item:
            flash('Room and cigarette type are required.')
            return redirect(url_for('order'))
        conn = get_db()
        conn.execute('INSERT INTO orders (room,item) VALUES (?,?)',(room,item))
        conn.commit()
        conn.close()
        flash('Order placed.')
        return redirect(url_for('index'))
    return render_template('order.html')

@app.route('/review/new/<int:order_id>', methods=['GET','POST'])
def new_review(order_id):
    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?',(order_id,)).fetchone()
    if not order:
        conn.close()
        flash('Order not found.')
        return redirect(url_for('index'))
    if request.method == 'POST':
        author = request.form.get('author','').strip()
        text = request.form.get('text','').strip()
        conn.execute('INSERT INTO reviews (order_id,author,text) VALUES (?,?,?)',(order_id,author,text))
        conn.commit()
        conn.close()
        flash('Review added.')
        return redirect(url_for('index'))
    conn.close()
    return render_template('new_review.html', order=order)

@app.route('/review/edit/<int:review_id>', methods=['GET','POST'])
def edit_review(review_id):
    conn = get_db()
    review = conn.execute('SELECT * FROM reviews WHERE id=?',(review_id,)).fetchone()
    if not review:
        conn.close()
        flash('Review not found.')
        return redirect(url_for('index'))
    if request.method == 'POST':
        author = request.form.get('author','').strip()
        text = request.form.get('text','').strip()
        conn.execute('UPDATE reviews SET author=?, text=? WHERE id=?',(author,text,review_id))
        conn.commit()
        conn.close()
        flash('Review updated.')
        return redirect(url_for('index'))
    conn.close()
    return render_template('edit_review.html', review=review)

@app.route('/orders/<int:order_id>')
def view_order(order_id):
    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?',(order_id,)).fetchone()
    reviews = conn.execute('SELECT * FROM reviews WHERE order_id=? ORDER BY created_at DESC',(order_id,)).fetchall()
    conn.close()
    if not order:
        flash('Order not found.')
        return redirect(url_for('index'))
    return render_template('order_view.html', order=order, reviews=reviews)

if __name__ == '__main__':
    app.run(debug=True)
